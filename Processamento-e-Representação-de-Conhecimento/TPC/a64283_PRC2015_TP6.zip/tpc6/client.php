 <?php
  require_once 'header.php';
if(isset($_REQUEST["type"])){
 
 require_once('./lib/nusoap.php');
 
 $location = 'http://localhost:8888/tpc6/server.php';
 $client = new nusoap_client($location, false);
 $type = $_REQUEST["type"];
 
 if($type == 'devolve_tabela'){
	 if(isset($_REQUEST["xml"])){
     $nome_ficheiro = $_REQUEST["xml"];
     $result = $client->call($type, array('xml' => $nome_ficheiro));
     }
 }
 
 else if(isset($_REQUEST["dia"]) && isset($_REQUEST["mes"]) && isset($_REQUEST["ano"])){

	$dia = $_REQUEST["dia"];
	$mes = $_REQUEST["mes"];
	$ano = $_REQUEST["ano"];
  $result = $client->call($type, array('dia' => $dia,'mes' => $mes,'ano' => $ano));
}
 
# Usar isto para obter os erros na criação do cliente
$err = $client->getError();
if($err){
  die( "#1 - fault: " . $err );
}

# usar isto para ver se o serviço está incessível
$err = $client->fault;
if($err){
  die( "#2 - fault: " . $err );
}else{
  # se não houver erros com o fault, verificar se houve erros ao usar o serviço
  $err = $client->getError();
  if($err){
    die( "#3 - fault: " . $err );
  }else{
    if($type=="devolve_tabela"){
    
     $dados = json_decode($result,true);
   
   

 echo "</div>
 <div class='container'>
 <table class='table table-striped'>
     <tr>
      <th>Nome</th>
      <th>Data nascimento</th>
      <th>Dia de nascimento</th>
     </tr>"; 

  
      for($i=0;$i<count($dados["registos"]);$i++){
      echo "<tr><td>".$dados["registos"][$i]["nome"][0]."</td>";
      echo "<td>".$dados["registos"][$i]["data"][0]."</td>";
      echo "<td>".$dados["registos"][$i]["dia_semana"]."</td></tr>";
      }
   
 echo "</table></div>";  
 
} 
 else  echo "<h3>O dia da semana da data  ".$dia."-".$mes."-".$ano." é </h3>  <h1 class='text-center'> <b>".$result."</b></h1>";


print <<<html
<br/>
<hr/>
<center><a class="back" href="client.php"> Voltar </a></center>
<hr/>
html;

   }
  }
 }

else{
  require_once 'header.php';
?>

 <h1 style="font-variant:small-caps">TP6 - Serviço sobre datas</h1>

 <button type="button" style="margin-top:40px;" id="dia_sem" class="btn btn-primary btn-lg">Dia da semana</button>
 <hr/>
 <button type="button" id="tabela" class="btn btn-primary btn-lg">Criar tabela</button>
   

<div class="row">
<div class="col-lg-12">
<form action="client.php" method="GET">
  <label for="dia">Dia</label>
  <input type="text" placeholder="02" name="dia"/>
  <label for="mes">Mês</label>
  <input type="text" placeholder="11" name="mes"/>
  <label for="ano">Ano</label>
  <input type="text" placeholder="2012" name="ano"/>

  <select class="option1" name="type">
    <option value="devolve_dia_da_semana">Dia da semana</option>
   </select>
  <input type="submit" value="Submeter"/>
</form>
</div>
</div>

<div style="margin-top:40px;" class="ficheiro">
  <form action="client.php" method="GET">
  <label for="xml">Ficheiro XML</label>
  <input type="text" placeholder="ficheiro" name="xml"/>
  <select class="option2" name="type">
    <option value="devolve_tabela">Criar tabela</option>
   </select>
  <input type="submit" value="Submeter"/>
  
  </form>	  
  
</div>

<div style="margin-top:40px;">
    <a class="back" href="client.php"> Voltar </a> 
  
</div>



<?php require_once 'footer.php'; } ?>