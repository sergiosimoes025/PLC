#!/usr/bin/perl -w

 use SOAP::Lite;
 use Switch;
 
 
my $data = shift;

my @array = split(/-./,$data,);

my $server = 'http://localhost:8888/tpc6/server.php';

print SOAP::Lite
  ->proxy($server)
  ->devolve_dia_da_semana($array[0],$array[1],$array[2])
  ->result;




