<?php
	
require_once('./lib/nusoap.php');

$server = new soap_server;
$server->register('devolve_dia_da_semana', array('dia' => 'xsd:integer','mes' => 'xsd:integer','ano' => 'xsd:integer'),
array('res' => 'xsd:string'));
$server->register('devolve_tabela',array('xml' => 'xsd:string'),
array('return' => 'xsd:string'));


function devolve_dia_da_semana($dia,$mes,$ano){	
	if($dia > 31 || $dia < 0 || $mes > 12 || $mes < 0 || $ano < 0){
		return "Data incorrecta!";
	}
	if(empty($dia) || empty($mes) || empty($ano)) return "Data incorrecta";
	
	$string = $ano."-".$mes."-".$dia;
	$timestamp = strtotime($string);
	$day = date('D', $timestamp);
	if($day == 'Fri') return "Sexta-Feira";
	if($day == 'Sat') return "Sábado";
	if($day == 'Mon') return "Segunda-feira";
	if($day == 'Sun') return "Domingo";
	if($day == 'Tue') return "Terça-feira";
	if($day == 'Wed') return "Quarta-feira";
	if($day == 'Thu') return "Quinta-feira";
}


function devolve_tabela($ficheiro){
	$xml = simplexml_load_file("xml/".$ficheiro);
    $response = array();
	$response["registos"] = array();
	
	foreach($xml as $registo){
		$reg = array();
		$reg["nome"] = $registo->nome;
		$reg["data"] = $registo->data;
		$date = DateTime::createFromFormat("Y-m-d", $registo->data);
		$reg["dia_semana"] = devolve_dia_da_semana($date->format("d"),$date->format("m"),$date->format("y"));
		array_push($response["registos"],$reg);
		}
		
		return json_encode($response);
}




$HTTP_RAW_POST_DATA = isset($HTTP_RAW_POST_DATA) ? $HTTP_RAW_POST_DATA : '';
$server->service($HTTP_RAW_POST_DATA);

?>
