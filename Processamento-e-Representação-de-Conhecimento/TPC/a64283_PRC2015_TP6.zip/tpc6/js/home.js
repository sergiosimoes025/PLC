$(document).ready(function(){
  $('.row').hide();
  $('.ficheiro').hide();
  
  $('#dia_sem').click(function(event){
    event.preventDefault();
    $('.option1').hide();
    $('#tabela').hide();
    $('.row').show();
  });
  
  $('#tabela').click(function(event){
    event.preventDefault();
    $('#dia_sem').hide();
    $('.option2').hide();
    $('.ficheiro').show();
  });
  
  $('.back').click(function(event){
     event.preventDefault();
     $('.row').hide();
     $('.ficheiro').hide();
     $('#dia_sem').show();
     $('#tabela').show();   
  });
}); 